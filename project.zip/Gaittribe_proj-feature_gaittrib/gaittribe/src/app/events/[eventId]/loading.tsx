export default function EventLoading() {
  return (
    <main className="section-shell py-10">
      <div className="card h-80 animate-pulse" />
    </main>
  );
}

